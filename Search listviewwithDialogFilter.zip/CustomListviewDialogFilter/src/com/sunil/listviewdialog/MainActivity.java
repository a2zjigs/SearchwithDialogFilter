package com.sunil.listviewdialog;

import java.util.ArrayList;
import java.util.Arrays;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;

public class MainActivity extends Activity implements OnClickListener, OnItemClickListener{

	private Button btn_listviewdialog=null;
	private EditText txt_item=null;
	private String TitleName[]={"Sunil Gupta","Ram Chnadra"," Abhishek Tripathi","Amit Verma","Sandeep Pal","Awadhesh Diwakar","Shishir Verma","Ravi Vimal","Prabhakr Singh","Manish Srivastva","Jitendra Singh","Surendra Pal"};
	private ArrayList<String> array_sort;
    int textlength=0;
    private AlertDialog myalertDialog=null;
    CustomAlertAdapter arrayAdapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		txt_item=(EditText)findViewById(R.id.editText_item);
		btn_listviewdialog=(Button)findViewById(R.id.button_listviewdialog);
		btn_listviewdialog.setOnClickListener(this);
	}
	@Override
	public void onClick(View arg0) {
		
		AlertDialog.Builder myDialog = new AlertDialog.Builder(MainActivity.this);
		
		final EditText editText = new EditText(MainActivity.this);
		final ListView listview=new ListView(MainActivity.this);
		editText.setCompoundDrawablesWithIntrinsicBounds(R.drawable.discoverseed_larg1, 0, 0, 0);
		array_sort=new ArrayList<String> (Arrays.asList(TitleName));
		LinearLayout layout = new LinearLayout(MainActivity.this);
		layout.setOrientation(LinearLayout.VERTICAL);
		layout.addView(editText);
		layout.addView(listview);
		myDialog.setView(layout);
//		arrayAdapter=new CustomAlertAdapter(MainActivity.this, array_sort);
//		listview.setAdapter(arrayAdapter);
		listview.setOnItemClickListener(this);
		
		arrayAdapter = new CustomAlertAdapter(MainActivity.this,array_sort);
		listview.setAdapter(arrayAdapter);
		MyTextWatcher myTextWatcher = new MyTextWatcher(editText, listview, MainActivity.this, array_sort);
	    editText.addTextChangedListener(myTextWatcher);
		
//		
//		editText.addTextChangedListener(new TextWatcher()
//	        {
//	            public void afterTextChanged(Editable s){
//	            	
//	            }
//	            public void beforeTextChanged(CharSequence s,
//	                    int start, int count, int after){
//	            	
//	            }
//	            public void onTextChanged(CharSequence s, int start, int before, int count)
//	            {
//	            	editText.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
//	                textlength = editText.getText().length();
//	                array_sort.clear();
//	                for (int i = 0; i < TitleName.length; i++)
//	                {
//	                    if (textlength <= TitleName[i].length())
//	                    {
//	                         
//	                        if(TitleName[i].toLowerCase().contains(editText.getText().toString().toLowerCase().trim()))
//	                        {
//	                            array_sort.add(TitleName[i]);
//	                        }
//	                      }
//	                }
//	                listview.setAdapter(new CustomAlertAdapter(MainActivity.this, array_sort));
//	                }
//	            });
//		
		
		myDialog.setNegativeButton("cancel", new DialogInterface.OnClickListener() {

	                    @Override
	                    public void onClick(DialogInterface dialog, int which) {
	                        dialog.dismiss();
	                    }
	                });

		myalertDialog=myDialog.show();
		
	}
	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3) {
		
			myalertDialog.dismiss();
			String strName=TitleName[position];
			txt_item.setText(strName);
	}

}
