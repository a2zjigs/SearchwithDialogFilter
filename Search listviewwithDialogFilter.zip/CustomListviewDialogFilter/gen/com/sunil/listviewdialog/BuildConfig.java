/** Automatically generated file. DO NOT MODIFY */
package com.sunil.listviewdialog;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}